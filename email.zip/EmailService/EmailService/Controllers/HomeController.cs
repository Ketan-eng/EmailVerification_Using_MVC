using EmailService.Models;
using EmailService.Services;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace EmailService.Controllers
{
    public class HomeController : Controller
    {
        private readonly IEmailService emailService;

        public HomeController(IEmailService emailService)
        {
            this.emailService = emailService;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(EmailModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            try
            {
                await emailService.SendAsync("your email", model.To, model.Subject, model.Body);
                
                return RedirectToAction(nameof(EmailSender));
            }
            catch (Exception ex)
            {
                TempData["Error"]= ex.ToString();
                return RedirectToAction(nameof(EmailSenderUnSuccess));
            }
        }
        public IActionResult EmailSender()
        {
            return View();
        }
        public IActionResult EmailSenderUnSuccess()
        {
            return View();
        }
    }
}
